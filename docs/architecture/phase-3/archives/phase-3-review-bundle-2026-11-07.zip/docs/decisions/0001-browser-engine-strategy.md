# ADR 0001: Browser engine strategy for Vezham Browser

- **Status:** Proposed; approval required before implementation
- **Date:** 2026-11-07
- **Decision owner:** Vezham Browser product/engineering
- **Scope:** macOS 26 Tahoe+ MVP page engine; internal distribution

## Context

Vezham Browser is an independent macOS 26 Tahoe+ browser with an engine-independent architecture, React/TypeScript + HeroUI v3 UI, Swift/AppKit native host, Go services where useful, phased Tamizhi, and optional Vezham ID/cloud capabilities. `@vezham/aura` is not ready and is excluded from dependencies, imports, placeholders, and assumptions. Distribution is internal-only. Accepted [ADR 0002](0002-browser-distribution-and-platform.md) requires Developer ID Application signing and notarized internal direct-distribution artifacts; installer/updater details and exact sandbox configuration remain open. The product prioritizes balanced performance, security, and web compatibility.

Static inspection of Arc 1.172.1 found a native macOS host linked to a proprietary Chromium-derived `ArcCore` framework with Blink/V8 and browser, renderer, and GPU helpers. This is only an architectural reference. Vezham will not use Arc source, binaries, assets, or branding. See [the Arc report](../../arc-macos-architecture-report.md).

The two candidate engines are Apple WebKit via `WKWebView`, and Chromium through a maintained embedder such as CEF. No engine is selected by prior assumption.

## Decision drivers

1. Keep the first release aligned with a native Swift/AppKit host.
2. Establish a security boundary between browser UI and remote page content.
3. Support multiple user profiles, private browsing, downloads/uploads, permissions, recovery, and durable browser history.
4. Avoid taking on more update/signing/sandbox work than needed to test the product.
5. Preserve an engine adapter boundary and report nonportable engine capabilities honestly.
6. Validate compatibility against named target sites before making broad claims.

## Options considered

### A. Apple WebKit through WKWebView

**Pros:** Native AppKit view; Apple documents persistent data stores by identifier and in-memory stores; public APIs cover navigation policy/events, find, zoom, cookies/website data, downloads/uploads, selected permission decisions, and content-process termination. macOS supplies the engine, so Vezham does not package a Chromium runtime or helper suite.

**Cons:** Engine release cadence follows macOS; API surface and security controls are less configurable than a browser-owned Chromium runtime. Safari/WebKit compatibility can differ from Chromium. Full Chrome-extension hosting and a general browser-level request-interception API are not documented for arbitrary WKWebView tabs.

### B. Chromium through CEF

**Pros:** Chromium/Blink compatibility; CEF provides a C/C++ embedder API and binary distributions; separate request contexts, browser/renderer/GPU helpers, download/permission/context-menu/find/zoom APIs, and sandbox support are documented.

**Cons:** CEF/Chromium packaging, helper apps, native bridging, sandbox configuration, nested signing, entitlements, notarization, licensing notices, security updates, and upgrade validation become Vezham responsibilities. CEF release availability can lag Chromium. Chrome and Alloy runtime feature sets differ; extension compatibility must be tested against a concrete API list.

### C. Direct custom Chromium integration

**Pros:** Maximum engine-level control.

**Cons:** Vezham would own substantially more of the engine integration, update, patch, process, and packaging surface. This is not justified for a macOS MVP when a maintained embedder is available for evaluation.

## Proposed decision

**Proposed candidate: evaluate WebKit through `WKWebView` for the macOS MVP.** No engine is selected. The strategy remains Proposed until the measurable gates in [the Browser MVP acceptance criteria](../architecture/browser-mvp-acceptance-criteria.md) have actual test evidence and product-owner acceptance. CEF/Chromium is a future alternative, not an active implementation. This ADR authorizes no engine implementation.

This is a proposed recommendation, not an implementation authorization. Keep this ADR in proposed status until the product owner approves it. Do not begin engine implementation before that approval.

## Rationale

For a first macOS release, WebKit appears to fit the fixed native Swift host and reduce engine packaging and security-update ownership. Apple documents browser primitives relevant to a profile-aware native view: persistent/in-memory website stores, load/navigation callbacks, find, zoom, data management, file panels, downloads, selected origin-scoped permissions, and content-process recovery notification. This is an API feasibility assessment, not evidence that Vezham’s workflows or isolation requirements have passed.

The main risk is whether WebKit’s compatibility and feature boundaries fit Vezham’s target users. This should be measured with a site/workflow matrix before scaling implementation. If those tests show that compatibility or demanded extension APIs cannot be met acceptably, CEF is the next candidate. It brings a Chromium engine but also requires substantial product-owned maintenance and release operations.

## Consequences

### Expected consequences if approved

- One native page engine and one native engine adapter in the MVP.
- No embedded Chromium helper suite or custom Chromium update stream at initial launch.
- React/TypeScript can remain decoupled through an opaque command/event contract.
- Product-owned history, tabs, permissions, profiles, and sync can be designed without tying public data models to one vendor’s engine types.

### Risks if the proposal is approved

- Some Chromium-optimized sites or authentication flows may behave differently under WebKit.
- No promise of Chrome extension compatibility.
- WebKit data stores do not imply independent OS accounts or configurable per-profile renderer processes.
- Engine-specific permissions, context menus, JavaScript worlds, history, and network interception will not map perfectly to the common contract.
- The app must test every supported macOS release and react to OS-driven WebKit changes.

## Required validation before an engine decision

1. Execute the target workflows for Google Workspace, Microsoft 365, GitHub, Figma, Notion, banking/payment sandbox portals, video conferencing, and Vezham test applications, on macOS 26.0 and the latest supported 26.x release. Record each critical step, repeated outcomes, limitations, and evidence.
2. Pass the required persistent-profile isolation, private non-persistence/cleanup, no-history/no-sync, and multiple-window profile-boundary tests. Any cross-profile or private-data leak is a hard failure.
3. Pass upload/download, site permission/TCC, find, zoom, durable-history, renderer-termination/recovery, and typed bridge-isolation tests; unknown permission kinds and unrecognized commands fail closed.
4. Measure startup, view creation, fixture loading, multi-view memory, representative workflows, and crash recovery against the provisional targets in the acceptance criteria; ratify or revise targets before testing.
5. Verify local browsing with Vezham ID, cloud, and Tamizhi endpoints unavailable; local browsing must work with zero requests to those endpoints.
6. Follow ADR 0002 for Developer ID signing and notarization. Decide the installer/updater details and validate sandbox/entitlements before producing a distributable build.
7. Review results and unresolved risks. Keep this ADR Proposed until explicit product-owner approval; only then may an implementation task be authorized.

## Revisit triggers

Reopen this ADR if:

- A documented high-priority workflow fails on WebKit and cannot be reasonably fixed at the app layer.
- A committed product requirement includes Chrome extension APIs that CEF’s pinned Chrome runtime can support.
- Vezham commits to a second desktop OS and cross-platform engine uniformity is worth the cost.
- Measured compatibility or performance data changes the tradeoff.

Any CEF adoption must be a separately approved ADR/update with pinned release, macOS helper/sandbox design, extension API matrix, size measurements, signing/notarization pipeline, and security-update SLA.

## Related documents

- [Engine comparison](../architecture/browser-engine-comparison.md)
- [Engine contract](../architecture/browser-engine-contract.md)
- [Browser threat model](../security/browser-threat-model.md)
- [Browser MVP acceptance criteria](../architecture/browser-mvp-acceptance-criteria.md)
- [Internal distribution and platform ADR](0002-browser-distribution-and-platform.md)
- [Arc static architecture report](../../arc-macos-architecture-report.md)
