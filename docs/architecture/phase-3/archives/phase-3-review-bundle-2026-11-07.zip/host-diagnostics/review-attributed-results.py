"""Independently cross-check raw guards/samples and derive requested variance."""
import hashlib,json,math,pathlib,statistics
TASK=pathlib.Path(__file__).resolve().parents[1]
session=json.loads((TASK/'work/attributed-checks-current.json').read_text())
evidence=pathlib.Path(session['evidenceDirectory'])
summary=json.loads((evidence/'attributed-checks-summary.json').read_text())
assert summary['status']=='completed bounded diagnostics'
crashes=[json.loads((evidence/f'crash-result-{i}.json').read_text()) for i in range(1,31)]
guards=[json.loads((evidence/f'crash-guard-{i}.json').read_text()) for i in range(1,31)]
for result,guard in zip(crashes,guards):
    assert result['status']=='passed' and result['failureCount']==0 and len(result['tests'])==7 and all(x['passed'] for x in result['tests'])
    assert guard['guardPassed'] and guard['host']['pid']!=guard['target']['pid']
    for key in ['resourceCoalitionID','jetsamCoalitionID']:assert guard['host'][key]==guard['target'][key] and guard['host'][key]>0
memory=json.loads((evidence/'memory-samples.json').read_text())
assert len(memory)==30 and all(x['secondsSinceReadyObserved']>=600 for x in memory)
initial=json.loads((evidence/'memory-initial-group.json').read_text());host=initial['host'];ids={r['pid']:r['uniqueID'] for r in initial['rows']}
for sample in memory:
    assert sample['hostPlusEngineRSSBytes']==sum(r['rssKiB']*1024 for r in sample['rows'])
    assert {r['pid']:r['uniqueID'] for r in sample['rows']}==ids
    assert all(r['resourceCoalitionID']==host['resourceCoalitionID'] and r['jetsamCoalitionID']==host['jetsamCoalitionID'] for r in sample['rows'])
assert summary['tenIdleViewsMemory']['ACPowerConfirmedAtStartAndEnd']
assert json.loads((evidence/'cleanup.json').read_text())['temporaryBuildRemoved']

def stats(values):
    ordered=sorted(values)
    return {'sampleCount':len(values),'median':statistics.median(values),'p95NearestRank':ordered[math.ceil(.95*len(values))-1],'maximum':max(values),'sampleVarianceNMinus1':statistics.variance(values)}
result={'status':'raw evidence cross-checked','method':'Recomputed from raw native results, per-signal guards and per-process RSS snapshots. Sample variance uses n-1. Sequential idle samples are not independent idle runs.','signalToResultObservedUpperBoundMs':stats([r['signalToResultObservedUpperBoundMs'] for r in crashes]),'callbackToDOMReadyMs':stats([r['callbackToDOMReadyMs'] for r in crashes]),'hostPlusEngineRSSBytes':stats([r['hostPlusEngineRSSBytes'] for r in memory]),'hostPlusEngineRSSMiB':stats([r['hostPlusEngineRSSBytes']/1048576 for r in memory]),'rawChecksPassed':210,'membershipAndIdentityStableAcrossMemorySamples':True,'helperCount':len(ids)-1}
assert result['signalToResultObservedUpperBoundMs']['p95NearestRank']==summary['crashRecovery']['signalToResultObservedUpperBoundMs']['p95']
assert result['hostPlusEngineRSSBytes']['maximum']==summary['tenIdleViewsMemory']['RSSBytes']['maximum']
project=TASK.parent/'https-chatgpt-com-share-6aee2c10-10e8'
result['measuredSourceSHA256']=summary['sourceSHA256']
result['currentSourceMatchesMeasuredRevision']=all(hashlib.sha256((project/'prototype/wkwebview/Sources'/name).read_bytes()).hexdigest()==value for name,value in summary['sourceSHA256'].items())
result['revisionScope']='Metrics describe the recorded measured source. Later prototype changes require separate validation; no current performance qualification is inferred.'
(evidence/'derived-statistics-and-review.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
