import json
import pathlib
import plistlib
import signal
import subprocess
import time

from process_metadata import metadata, snapshot

TASK=pathlib.Path.cwd()
CURRENT=json.loads((TASK/'work/process-attribution-current.json').read_text())
WORK=pathlib.Path(CURRENT['temporaryDirectory'])
EVIDENCE=pathlib.Path(CURRENT['evidenceDirectory'])
HOST=int(CURRENT['hostPID'])
APP=pathlib.Path(CURRENT['appPath'])
CONTROL=WORK/'control/VezhamWKPrototype.app'
BUNDLE=CURRENT['bundleIdentifier']+'.Control'
RUN=CURRENT['runID']+'-control'
RESULTS=pathlib.Path('/Users/vigneshwaranbhoj/Library/Containers')/BUNDLE/'Data/Library/Application Support/WKPrototype'

before=metadata(HOST)
assert before['executablePath']==str(APP/'Contents/MacOS/VezhamWKPrototype')
subprocess.run(['/usr/bin/ditto',str(APP),str(CONTROL)],check=True)
subprocess.run(['/usr/libexec/PlistBuddy','-c','Set :CFBundleIdentifier '+BUNDLE,str(CONTROL/'Contents/Info.plist')],check=True)
normal=TASK.parent/'https-chatgpt-com-share-6aee2c10-10e8/prototype/wkwebview/entitlements.plist'
subprocess.run(['/usr/bin/codesign','--force','--sign','-','--options','runtime','--entitlements',str(normal),str(CONTROL)],check=True,capture_output=True)
subprocess.run(['/usr/bin/codesign','--verify','--strict',str(CONTROL)],check=True,capture_output=True)
waiter=subprocess.Popen(['/usr/bin/open','-n','-W','-a',str(CONTROL),'--args','--test-ten-idle-views','--test-run-id',RUN],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
ready=RESULTS/('idle-ready-'+RUN+'.json')
control_pid=None
try:
    for _ in range(240):
        if ready.exists():break
        if waiter.poll() is not None:raise RuntimeError('Control app exited before ready')
        time.sleep(.25)
    data=json.loads(ready.read_text());assert data['viewCount']==10
    control_pid=int(data['hostPID']);control_identity=metadata(control_pid)
    assert control_identity['executablePath']==str(CONTROL/'Contents/MacOS/VezhamWKPrototype')
    main=snapshot(HOST);control=snapshot(control_pid)
    a=main['host'];b=control['host']
    assert a['uniqueID']==before['uniqueID']
    assert a['resourceCoalitionID'] and b['resourceCoalitionID']
    assert a['resourceCoalitionID']!=b['resourceCoalitionID']
    assert a['jetsamCoalitionID']!=b['jetsamCoalitionID']
    def members(sample,host):
        return [p for p in sample['processes'] if p['resourceCoalitionID']==host['resourceCoalitionID'] and p['jetsamCoalitionID']==host['jetsamCoalitionID'] and p['executablePath'] and '/WebKit.framework/' in p['executablePath']]
    first=members(main,a);second=members(control,b)
    assert len([p for p in first if p['executablePath'].endswith('/com.apple.WebKit.WebContent')])==10
    assert len([p for p in second if p['executablePath'].endswith('/com.apple.WebKit.WebContent')])==10
    assert not ({p['pid'] for p in first}&{p['pid'] for p in second})
    result={'status':'validated-on-current-host','method':'Read-only private Darwin coalition/unique-ID ABI, validated against two simultaneous isolated LaunchServices apps and their executable paths. Not a public WebKit product API.','mainHost':a,'controlHost':b,'mainHelpers':first,'controlHelpers':second,'sameLaunchdParentDoesNotConflateGroups':all(p['ppid']==1 for p in first+second),'mainViewCount':10,'controlViewCount':10,'sources':['https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/sys/proc_info_private.h','https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/osfmk/mach/coalition.h'],'guard':'Crash target must be a WebKit WebContent executable in the test host resource and jetsam coalitions, retain its kernel unique ID on immediate recheck, and be absent from other app groups.'}
    (EVIDENCE/'two-host-attribution-validation.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('Attribution validated: two distinct hosts, 10 distinct WebContent processes each; no overlapping helper PIDs.',flush=True)
finally:
    if control_pid is not None:
        now=metadata(control_pid)
        if now['uniqueID']==control_identity['uniqueID'] and now['executablePath']==control_identity['executablePath']:
            os_result=subprocess.run(['/bin/kill','-TERM',str(control_pid)],capture_output=True,text=True)
            print('Closed isolated control host:',os_result.returncode,flush=True)
    try:waiter.wait(timeout=10)
    except subprocess.TimeoutExpired:pass
