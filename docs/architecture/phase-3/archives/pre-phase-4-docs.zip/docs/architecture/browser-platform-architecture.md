# Browser Platform Architecture

**Status:** Proposed implementation architecture  
**Platform baseline:** macOS 26 Tahoe and later  
**Distribution:** Internal-only; see [distribution architecture](browser-distribution.md)

## Product decisions

- Browser chrome uses React + TypeScript + HeroUI v3.
- The native host uses Swift + AppKit.
- The browser core and product-facing data models remain engine-independent.
- WKWebView is the proposed initial engine adapter, pending the acceptance gates in ADR 0001. Chromium/CEF remains future evaluation only, not an active implementation.
- `@vezham/aura` is not ready. Do not add it, import it, create a placeholder, or assume its APIs.
- Local browsing must remain usable when Vezham ID, Tamizhi, sync, or other Vezham cloud services are unavailable.

## Process and trust separation

The native AppKit host owns app lifecycle, windows, profile orchestration, local persistence, permission policy, Keychain access, file panels, downloads coordination, update policy, and engine-view lifecycle. The browser core defines engine-independent operations and policy. React renders browser chrome inside a dedicated, app-owned UI web view or equivalent isolated UI surface.

Remote websites render only in engine-managed content views. Do not load arbitrary websites in the privileged browser UI view. Do not expose the browser UI's native bridge, account state, file access, or privileged commands to website content. UI resources should be bundled and served from a fixed app-controlled origin/scheme; navigation away from that origin is denied or opened as website content in a separate view after native policy checks.

The React-to-native boundary consists of versioned typed commands and events. Swift validates message shape, size, enum values, identifiers, current profile/view ownership, caller origin, and authorization for every command. The bridge is allowlisted; unknown commands fail closed. Avoid generic method dispatch and arbitrary native object exposure. Website content has no direct bridge. Any page script execution remains explicit, narrowly scoped, page-world functionality, and distinct from browser UI commands.

## Engine adapter boundary

The browser core owns opaque `ProfileId`, `ViewId`, navigation IDs, history and permission records, and capability declarations. It does not expose WKWebView or CEF objects to React. A native adapter maps product operations onto an engine and reports `supported`, `partial`, or `unsupported` capabilities with version context.

WKWebView is the proposed first adapter because it is native to the AppKit host and uses the system WebKit runtime. That proposal depends on proof of data-store behavior and target-site compatibility. Do not claim that `WKWebsiteDataStore` automatically provides complete profile or security isolation: validate persistent stores by identifier, non-persistent stores, cookies, local storage, IndexedDB, service workers, caches, concurrent views, deletion behavior, and crash recovery on the supported OS. CEF is not in the active implementation plan; a later evaluation must separately address runtime size, helper apps, sandbox, signing, extension needs, security updates, and licensing.

## Storage and optional services

Use distinct persistent engine data stores for persistent browser profiles and an in-memory, non-persistent store for private browsing. Keep browser-owned state (history, bookmarks, permissions, downloads metadata, settings) in a profile-keyed local store. Credentials and Vezham ID tokens belong in Keychain, not web content, React state persistence, logs, or sync payloads. Private browsing does not write to persistent browser history or sync and must clean up its in-memory store when its private session ends.

Tamizhi is phased and disabled unless a user invokes a defined feature. Any page-derived data transfer requires explicit, understandable consent and least-data selection. Vezham ID and cloud sync are optional capabilities. Local browsing, bookmarks/history stored locally, and the engine itself must not depend on cloud reachability.

## App security and release

Use Developer ID Application signing and notarization for internal direct distribution, with minimal App Sandbox entitlements and a documented justification for every exception. Exact sandbox and hardened-runtime configuration remains an implementation gate. Distribution channels, signed update metadata, artifact integrity, rollout, rollback, minimum version, and revocation are defined in [browser distribution](browser-distribution.md).

## Implementation sequence

1. Validate the proposed WKWebView data-store, view lifecycle, crash recovery, and native UI separation on macOS 26.
2. Prove the typed bridge with origin enforcement and negative tests; no page-to-native bridge.
3. Prototype only the minimum engine contract slice after ADR 0001 gates and owner approval.
4. Validate security acceptance criteria and target-site workflows before expanding product UI.

No browser UI or engine adapter is authorized by this architecture document.
