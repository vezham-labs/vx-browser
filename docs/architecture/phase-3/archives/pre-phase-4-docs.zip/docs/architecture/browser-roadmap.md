# Vezham Browser workflow and validation sequence

**Sequencing decision:** The product owner scheduled developer code signing/Apple notarization and macOS 26 runtime verification for the final release-validation stage. These are unverified release conditions, rather than blockers for current Phase 3 work.

| Stage | Work | Status |
|---|---|---|
| Phase 1 | Architecture and engine research | Documentation complete |
| Phase 2 | Internal distribution and security architecture | Documentation complete; ADR 0002 Accepted |
| Phase 3 | Native feasibility investigation | Authorized local/public evidence collected; remaining non-deferred validation is tracked in the [gate review](prototype/phase3-final-review.md) |
| Phase 4 | Review evidence and decide on the engine | Review package prepared; ADR 0001 remains Proposed until explicit user approval |
| Phase 5 | Browser foundation | Production engine implementation begins only after engine approval; future chrome is React + TypeScript + HeroUI v3 with a Swift + AppKit host and an engine-independent core |
| Final release validation | Developer ID code signing, Apple notarization and distribution checks; macOS 26.0/latest supported 26.x runtime verification | Deferred to this final stage by user direction; required before internal release |

The current host remains macOS 27.2 and the build target/minimum remains macOS 26.0. Public-page-only testing remains in force. Native denial, 30 bounded content-process recoveries and an attributed ten-view aggregate-RSS observation now have evidence. Actual-window recovery passed 49 checks across A/B/Private and 48 existing regression checks passed on the same revision. Full permission lifecycle, durable recovery/in-flight crash cases, controlled performance and other product-feature gaps remain open. This sequencing change does not approve the engine, mark an unexecuted test as passed, or waive security protections.

Chromium/CEF remains evaluation-only. Aura and production Tamizhi/cloud dependencies remain excluded.
