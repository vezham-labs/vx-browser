# Phase 5 — MVP foundation and implementation preparation

**Prepared and reviewed:** 2026-11-07, Phase 4.2. **Execution status:** Not Started. This folder is a kickoff plan, not production source, a build/test run or a deployment authorization.

## Authority and starting state

The [Product Owner decision](../phase-3/owner-approval-decision.md) records exactly: **Phase 3 closure — APPROVED; WKWebView engine — CONDITIONAL ACCEPTANCE for MVP planning and implementation; architecture baseline — APPROVED.** Conditional acceptance is not unconditional production-engine or release approval. [ADR 0001](../../decisions/0001-browser-engine-strategy.md) remains **Proposed**, with its completed, reviewed Phase 4.1 correction and Stage A/B/C gates verified unchanged; no Accepted transition is inferred. Its lifecycle label does not require the three decisions to be requested again.

A separate scoped implementation instruction is needed to start Phase 5 execution. The current Phase 4.2 task ends after documentation and consistency review. No milestone below has been executed or marked Passed by preparing this folder.

## Read in order

1. [Scope and milestones](phase-5-scope-and-milestones.md) — allowed work, M0-M8 sequence, dependencies, acceptance criteria, risks and implementation/final-release separation.
2. [Implementation plan](phase-5-implementation-plan.md) — concrete work packages, prerequisite design choices, gate/evidence discipline, bounded future verification and exit conditions.
3. [Approved architecture baseline](../phase-3/browser-mvp-architecture-baseline.md) — approved boundaries and deliberately unresolved implementation details.
4. [Primary Phase 3 exit review](../phase-3/phase-3-exit-review.md) and [unchanged gate snapshot](../phase-3/browser-acceptance-gate-ledger.md) — existing evidence and continuing requirements. The historical B12 approval-blocked row is superseded only for the three owner decisions by the dated approval record; technical classifications/results are unchanged.

## Non-negotiable constraints

- macOS **26.0+** minimum; Swift/AppKit native host; React + TypeScript + HeroUI v3 chrome; engine-independent core and opaque adapter boundaries.
- **No `@vezham/aura`**, including dependencies, imports, placeholders or API assumptions.
- **No Chromium/CEF implementation.** CEF stays evaluation-only; no runtime/helper/package or CEF-specific placeholder adapter is added by this plan.
- **No public distribution.** Internal release remains a separate, gated release decision under accepted [ADR 0002](../../decisions/0002-browser-distribution-and-platform.md).
- **No production Tamizhi integration.** Vezham identity/cloud remains optional, outside the required local-browsing path; it is not an implementation prerequisite or an implicitly authorized feature.
- No mandatory security/release gate is removed. No unknown, blocked, deferred or untested criterion is Passed through planning or owner approval.
- Do not edit/restart the Phase 3 prototype, rewrite historical evidence or reuse older performance as new-revision qualification. The separate 49/49 recovery and 48/48 regression outcomes remain historical inputs, not Phase 5 acceptance.

## Stage separation and stop point

Outstanding ADR **Stage A** critical-workflow and risk-disposition questions remain explicit before the affected implementation choices. M0-M7 cover future implementation/integration and preparation of an internal release candidate under **Stage B**. M8 is **Stage C final-release validation**, including the user-deferred macOS 26.0/latest supported 26.x runtime matrix and Developer ID signing/notarization. Plan release infrastructure earlier; do not use the final-stage timing to waive or pre-pass it. Account/media workflows remain access-blocked until separately approved, and release cannot treat those blockers as compatibility proof.

The smallest future kickoff is M0 only, after a scoped execution instruction: establish the implementation repository/target/module boundaries and resolve immediate design prerequisites. This task creates no production repository scaffolding, code, build pipeline, tests, credentials, automation or release artifact. Stop after review of these documents.
