# Phase 5 scope and milestones

**Date:** 2026-11-07. **Status:** prepared and reviewed plan; every milestone is **Planned / Not Started**. Acceptance criteria below describe future evidence, not completed tests. Phase 4.2 performs no implementation, builds or tests.

## Approved direction and scope

Use the [owner approval record](../phase-3/owner-approval-decision.md) and [approved boundary baseline](../phase-3/browser-mvp-architecture-baseline.md): Phase 3 closure APPROVED; WKWebView CONDITIONAL ACCEPTANCE for MVP planning and implementation; architecture baseline APPROVED. The conditional choice does not establish unconditional production-engine or release readiness. ADR 0001 remains Proposed after consistency correction; it does not revoke the already given conditional direction.

In scope for later authorized implementation: native foundation, an engine-independent browser core/local state, one WKWebView adapter, React/TypeScript/HeroUI v3 chrome, validated trust boundaries, profiles/private sessions, native permission/file services, local-first compatibility/reliability and internal release engineering. Core runtime/storage/transport and release technology choices are still explicit design tasks, not silently selected by baseline approval.

Excluded: Aura, Chromium/CEF implementation, public distribution and production Tamizhi. Optional Vezham identity/cloud is outside the required foundation and cannot be required to browse. The plan does not authorize even an optional account/sync feature implementation without its own scope. Phase 3 source/evidence/manifests/archives stay immutable references.

## Alignment with the completed Phase 4.1 policy

[ADR 0001](../../decisions/0001-browser-engine-strategy.md) is already corrected, reviewed and retained unchanged with status Proposed. Its Stage A/B/C sequence does not rename the gate ledger's A/B/C/D categories.

| Validation stage | Phase 5 dependency / obligation |
|---|---|
| **Stage A — Before engine selection** | Owner closure/conditional engine/baseline decisions are recorded. Name outstanding launch-critical workflows/capabilities and unresolved-risk dispositions in M0 before dependent design choices; account/media restrictions persist. A decision-critical condition that cannot be accepted requires finite authorized validation or a hold on the affected scope. No broad Phase 3 retry loop. |
| **Stage B — During implementation** | M0-M7 implement and validate the approved boundaries, native/core/adapter/chrome, profile/private, permission/file and lifecycle behavior plus authorized critical compatibility. No hard leak or unauthorized action is deferred past reliance on that feature. |
| **Stage C — Before final release** | M8 qualifies the pinned candidate on the required macOS 26 runtime, Developer ID/notarization, Gatekeeper, App Sandbox, Hardened Runtime, entitlements, compatibility/performance and internal distribution/updater matrix. Final-stage scheduling never waives a requirement or pre-passes a result. |

## Sequence and dependencies

M0 → M1 → M2 → M3 → M4 → M5 → M6. M3's trust-boundary slice must be verified before privileged UI commands are exposed; static UI design may be prepared in parallel but may not bypass the dispatcher. M5 backend service design can overlap M3/M4, while integrated privacy/permission/file acceptance waits for all dependencies. M7 release design can begin after M0 and develop alongside M6 once dependencies stabilize. M8 depends on completed implementation and resolved release-critical conditions; minimum-OS runtime/signing/notarization stay at this final stage.

| Milestone | Entry/dependencies | Planned outputs | Acceptance / exit criteria for later execution | Ledger mapping |
|---|---|---|---|---|
| M0 — Foundation and native host | Scoped execution instruction; owner record and approved baseline | Implementation workspace/target/module map, macOS 26.0 deployment target, Swift/AppKit lifecycle/window shell, native service ownership, immediate design decisions and outstanding launch-critical workflow/capability/risk dispositions before their dependent choices. Preserve Phase 3 as reference only. | Later authorized development build/launch on recorded host; lifecycle shutdown and supported-target configuration evidenced without weakening protections. No engine/private types in public core models; no cloud/Aura/CEF dependency. | A01, A15, A23; D01, D04 |
| M1 — Browser core and local state | M0; core placement and storage choices recorded before use | Engine-neutral identifiers/commands/events, lifecycle policy, profile-keyed state, committed-only history/bookmarks/settings/download metadata, migrations and private ephemeral policy. | Core can be exercised without WK types; transactions/migrations and invalid ownership/deletion paths have scoped evidence. Private visits never enter normal durable history/suggestions. | D01, D05-D07, D10-D11, D15 |
| M2 — WKWebView engine adapter | M0-M1; public SDK/capability mapping | Conditional WK integration behind the engine contract: website stores, navigation policy, page-view lifetimes, correlated events, error/capability semantics and explicit recovery. | Pinned source/SDK/engine context; valid navigation/history events and rejected stale/disposed/foreign callbacks; committed-URL recovery only under explicit policy; unsupported capabilities fail clearly. No private process ABI in product. | A02-A07, A10, A14, A20-A22; D04, D11, D14 |
| M3 — Security and chrome/native trust boundary | M0-M2 contract/ownership slice; privileged surface design resolved | Dedicated app-owned chrome origin, bundled resources/CSP, typed versioned native dispatcher, schema/size/origin/frame/ownership/replay checks and sanitized event channel. | Legitimate commands operate only on their owned view/profile; at least 100 defined malformed/hostile message cases rejected with no privileged side effect. Remote pages have no native channel; chrome cannot retain privilege on remote navigation. | A11, A21-A22; D02-D04, D16 |
| M4 — React + TypeScript + HeroUI v3 interface | M2-M3 validated minimal transport; M1 product model | Address/navigation, tab/window/profile presentation, status/recovery, find/zoom and origin/profile-labelled native-service interactions; accessible user flows. | Actual UI actions map to validated commands and current state; no raw engine objects/paths/tokens; stale results cannot mutate a replacement view; required keyboard/accessibility and error/cancel flows evidenced. | A14; D02, D06, D12-D13, D16 |
| M5 — Profiles, private sessions and native service lifetimes | M1-M4 integrated slices; permission/transfer policy choices | Persistent A/B and shared private-session ownership, safe profile deletion, permission decisions/records and native file broker/staged downloads; Keychain boundary where applicable. | Zero synthetic cross-profile/private leakage in scoped workflows; last-owner cleanup and active deletion refusal; allowed selection only, cancellation/no upload, exact completed bytes, interrupted staging safety and defined scope/metadata behavior. Actual grants remain separately access-authorized. | A03-A05, A08-A09, A12-A13, A21-A22; B09; D05-D10, D14 |
| M6 — Compatibility, reliability and local-first qualification | M1-M5 usable integration; named critical subflows/access scope | Integrated local browsing/outage behavior, in-flight and multi-view recovery/lifecycle, transfer edge cases, public compatibility; authorized critical account/media workflows and revision-specific performance. | Evidence pinned to the Phase 5 revision; all approved launch-critical steps scored with failures/blocks explicit; local history/bookmarks/profiles work with zero Vezham service requests; applicable reliability/security/performance targets met. Blocked account rows remain blocked, not a complete compatibility milestone. | A07, A16-A19, A21-A22; B01-B11; C08, C10; D14-D17 |
| M7 — Internal distribution engineering and release readiness | ADR 0002/M0 decisions; stable dependency/module inventory; can overlap M6 | Select installer/updater/internal-channel design; implement artifact/metadata verification, staging, replay/channel/rollback/minimum-version/revocation controls; prepare signing/key custody and release procedures. | Implementation and isolated verifier-failure evidence plus dependency/provenance/runbook review; actual Developer ID/notarization, clean release install and macOS 26 runtime remain unpassed M8 gates. No public endpoint or distribution. | C02-C07, C09-C10; D18 |
| M8 — Final-release qualification and internal release decision | M0-M7 complete; candidate pinned; critical B blockers resolved or product scope explicitly narrowed without waiving security | Final macOS 26.0/latest supported 26.x matrix; actual Developer ID signing/notarization, Gatekeeper/clean install, release entitlements, updater integrity/operations, current compatibility/performance and dependency/security review. | All applicable mandatory gates evidenced on the candidate; no unresolved hard security/profile defect or untested launch-critical workflow; release owner explicitly authorizes any internal distribution. Never implied by conditional engine acceptance. No public distribution. | C01-C10; relevant A/B/D implementation criteria |

Ledger IDs refer to the unchanged [Phase 4 gate snapshot](../phase-3/browser-acceptance-gate-ledger.md). They identify obligations, not permission to run restricted tests or historical passes that transfer to Phase 5. Create future milestone evidence separately; preserve the old ledger's categories/statuses and resolve only the three administrative approvals through the dated owner record.

## Implementation-stage versus final-release requirements

| Implementation stage: M0-M7 | Final-release stage: M8 |
|---|---|
| Record repository/module ownership, native authority, core/adapter and UI contracts; implement behavior under separate execution tasks. | Qualify the actual pinned release candidate on macOS 26.0 and latest supported 26.x; newer-host builds alone are insufficient. |
| Keep build target/minimum at 26.0 from M0. Development evidence uses recorded host/runtime and appropriate minimal protections. | Verify Developer ID signatures, Apple notarization, Gatekeeper/clean install, actual nested code/entitlements and unsupported-OS rejection. |
| Implement/verify privacy, bridge, file and permission policy before relying on it. Resolve failures at the relevant milestone, not merely at release. | Require all applicable security/privacy/critical workflow gates and exact-candidate performance evidence; no hard leak/unauthorized action or critical access block may be called Passed. |
| Implement release integrity, channels, rollout/rollback/minimum-version/revocation logic and prepare runbooks before final validation. | Validate actual internal delivery/MDM path as selected, tamper/replay/wrong-channel/revoked-release rejection and release/key-response operations. |
| Public and synthetic checks only until account/media scope is separately approved. Blocked work does not prohibit unrelated safe foundation implementation. | Any release-critical account/media workflow must be evidenced in its approved environment, or explicitly removed from product scope by the owner; no security waiver or silent skip. |

No public distribution is authorized at any milestone. No internal distribution occurs merely because this plan exists; the candidate needs separate release authorization. Signing/notarization and macOS 26 validation are deferred in schedule, not optional requirements. Mandatory security implementation gates are not postponed to M8 simply because release qualification is final-stage.

## Approved performance targets to retain

| Measurement | Target | Qualification limit |
|---|---|---|
| Engine initialization to ready | p95 ≤2.0 s | Define the actual readiness boundary; record true cold launch separately. |
| Empty view creation after engine ready | p95 ≤500 ms | State whether constructor and asynchronous renderer-ready time are separate; constructor-only evidence cannot imply readiness. |
| Deterministic 1 MB fixture to DOM-ready | p95 ≤1.5 s | Confirm payload/method and source/runtime revision. |
| Ten idle views after ten minutes | Host + attributable engine processes ≤1.5 GB RSS | Record attribution, compressed-memory/RSS limits and sampling; no host-only substitution. |
| Crash recovery to visible error/reload state | p95 ≤2.0 s | Measure the specified visible state, not an unrelated hidden automatic-reload proxy. |

Use the [approved measurement rules](../browser-mvp-acceptance-criteria.md#performance-and-resource-gates-targets-approved-2026-11-07): named machine, AC power, documented state, 30 samples per applicable measurement, median/p95/variance and limitations. Also record cold launch, idle CPU, energy when available, 30-minute representative workflow memory and conferencing peaks when authorized/in scope. Phase 3 numbers remain historical. No new result is produced here.

## Risks and stop/exit conditions

| Risk/dependency | Required disposition |
|---|---|
| Unresolved core runtime, local store, UI origin/transport, permissions or transfer semantics | Resolve/document the choice before its dependent work package; do not replace approved boundaries with convenience coupling. |
| Account/MFA/SSO/passkey/edit/payment/conference compatibility unknown | Name launch-critical subflows and approved environments. Keep current public-only/account/media restrictions; do not repeatedly retry without access or new information. |
| Profile/private leak, page-to-native privilege escalation or unauthorized file/device access | Stop affected milestone and release; remediate and produce scoped evidence. Conditional acceptance cannot waive a hard defect. |
| Broader stale/disposal/in-flight recovery and file lifetime behavior unknown | Add finite implementation-revision cases at M5/M6; no reopening endless Phase 3 prototype loops. |
| OS-driven engine changes and unqualified current performance | Assign platform/security response ownership and qualify exact future revisions; no inherited benchmark pass. |
| Installer/updater/key custody/rollout choices or release access unavailable | Design/prepare under M7, keep actual release checks blocked/deferred until prerequisites exist, and do not distribute. |
| ADR lifecycle remains Proposed | Keep formal status unchanged pending an explicit status disposition. Use the recorded conditional decisions as authority within scope; do not demand their reapproval or infer unconditional production acceptance. |

Each future milestone exits only when its declared criteria have evidence or an explicit allowed partial/blocked disposition. A blocked external workflow may allow unrelated development to continue; it does not complete compatibility or release. A failed verification may be retried only after a recorded code/environment/method change or a justified new diagnostic question. Phase 3 closure stays approved regardless of new Phase 5 work; new defects belong to their own revision record.

Phase 5 overall exit means an implemented, internally release-eligible MVP with accepted evidence for all applicable mandatory gates and a separate release-owner decision. Until then it is incomplete/conditional; no complete browser readiness, public distribution or unconditional engine acceptance is inferred.
