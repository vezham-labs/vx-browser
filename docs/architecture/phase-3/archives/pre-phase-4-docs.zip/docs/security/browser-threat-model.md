# Vezham Browser Threat Model

**Status:** Proposed baseline for Phase 2 design review  
**Scope:** Internal-only macOS 26 Tahoe+ product; untrusted web content; React/TypeScript + HeroUI v3 browser UI; Swift/AppKit host; phased Tamizhi; optional Vezham ID/cloud sync. `@vezham/aura` is excluded. This model does not certify either engine as secure. Measurable validation gates are in [the browser MVP acceptance criteria](../architecture/browser-mvp-acceptance-criteria.md).

## Security objectives

- A compromised page or renderer cannot read browser UI state, other profiles, credentials, local files, or privileged app data.
- Users can understand and control site permissions, file transfer, AI page access, and cloud sync.
- Profile boundaries are enforced in engine storage and app-owned state.
- Browser engine and helper processes run with the least privileges compatible with their role.
- Engine crashes, malicious pages, or sync failures do not silently expose or corrupt unrelated browser data.

## Assets and trust boundaries

### Assets

- Vezham ID access/refresh tokens, Keychain items, account identifiers, and device keys.
- Website cookies, HTTP authentication, local storage, IndexedDB, service-worker data, and caches.
- Browser history, bookmarks, downloads, open tabs, profile labels, and permission decisions.
- Page content, selected text, screenshots, DOM-derived data, and AI prompt/response data.
- Downloaded files, upload selections, file bookmarks, and user-selected paths.
- Engine update artifacts, code-signing credentials, helper entitlements, and release pipeline secrets.

### Boundaries

1. **Web renderer to browser host:** untrusted page content and scripts must not call arbitrary native methods.
2. **React browser chrome to native host:** the app-owned UI communicates through a versioned, typed allowlist; Swift validates and authorizes each request. The chrome surface must not load remote content, and UI-origin XSS is treated as a privileged compromise.
3. **Browser core to engine adapter:** core owns profiles, durable history, permission/download policy, and orchestration. The adapter translates core policy into engine calls and reports capabilities; engine objects and private APIs do not leak into product state.
4. **Native host to remote content:** website views are a separate untrusted surface with no privileged app message handler, account tokens, browser UI DOM, or unrestricted filesystem access.
5. **Renderer to browser/OS services:** WebKit or Chromium brokers network, filesystem, GPU, and device requests under engine and OS policy.
6. **Profile to profile:** site state, app history, permissions, downloads metadata, and sync records are profile-scoped.
7. **Local app to optional cloud services:** Vezham ID and sync may transmit account or profile data outside the device; local browsing cannot depend on them.
8. **Page content to Tamizhi:** explicit user action may move minimized page-derived information to the intelligence layer and, only under the disclosed mode, to remote AI infrastructure.
9. **Build pipeline to internal app distribution:** engine frameworks/helpers, licenses, signing identity, and update artifacts enter the app. Accepted ADR 0002 requires Developer ID Application signing and notarized internal direct-distribution artifacts; updater, installer, and exact sandbox details remain implementation decisions.

## Threat actors and assumptions

- Malicious or compromised websites, ads, redirects, downloads, and embedded frames.
- A renderer exploit attempting to escape process restrictions or access another tab/profile.
- A compromised extension, if extensions are introduced later.
- Malware or another local user with access to the same macOS account; the MVP does not claim protection against a fully compromised OS account.
- A hostile or compromised network/cloud endpoint.
- An AI prompt-injection page attempting to instruct Tamizhi or induce the browser to disclose data.
- Build/release dependency compromise or stale engine security fixes.

Assume web content is hostile from first byte. Treat a renderer as compromised for design purposes; Chromium’s own sandbox guidance uses this assumption. [Chromium sandbox design](https://chromium.googlesource.com/chromium/src/+/main/docs/design/sandbox.md)

## Controls by threat area

| Threat | Required controls | Residual risk / validation |
|---|---|---|
| Untrusted web content attacks native UI | Separate browser chrome from page rendering. Use a dedicated app-owned UI origin/view. Deny navigation from browser UI surface to arbitrary websites. Validate every typed UI-to-Swift command. Never expose Swift objects or generic RPC to page JavaScript. | XSS in the browser UI is a privileged UI compromise. Apply CSP, safe templating, dependency review, and origin checks. |
| Native bridge confused-deputy or code execution | No generic page-to-native bridge. Do not expose arbitrary JavaScript source evaluation in the product command contract. If future page extraction is approved, expose fixed browser-owned operations (such as read selection) behind a short-lived, user-initiated, purpose-bound grant and return bounded structured data. Do not interpolate page strings into executable code or place auth tokens, file paths, profile paths, or app secrets in page worlds. | Engine-specific isolated-world support differs. Even fixed extraction can be manipulated by page content; test call paths and keep disabled until Tamizhi data-flow policy is approved. |
| Renderer compromise | Prefer engine-managed content processes; keep browser UI, account, and profile control in the native host. Use WebKit process isolation or configure CEF’s per-role helpers and sandbox. Do not disable CEF sandbox for convenience. Keep renderer, GPU, and generic helper entitlements minimal and distinct. | Engine sandbox vulnerabilities remain possible. CEF sandboxing is opt-in/configuration-sensitive on macOS and requires correct helper startup and signing. [CEF sandbox setup](https://chromiumembedded.github.io/cef/sandbox_setup) |
| Profile leakage | Assign immutable profile IDs and per-profile WebKit data-store IDs or CEF request-context/cache directories. Key Vezham-owned history, permission policy, bookmarks, downloads metadata, and sync by profile ID. Block cross-profile window creation unless an explicit browser action selects a destination profile. | Same macOS user and engine implementation remain shared. Do not describe profiles as separate OS users or hard security compartments. Test cookies, local storage, IndexedDB, service workers, and private-mode cleanup. |
| Credentials and authentication | Keep Vezham ID credentials and sync keys in Keychain. Do not expose them to pages or Tamizhi prompts. Avoid a localhost privileged service; if Go services run locally, bind only as needed and require per-session unguessable auth plus origin validation. | Keychain and App Sandbox mitigate access but cannot protect against compromise of the signed host process or user account. [Keychain Services](https://developer.apple.com/documentation/security/keychain-services) |
| Downloads | Require explicit policy for destination, filename normalization, duplicate names, cancellation, and profile association. Use system save panels/security-scoped access. Do not execute/open files automatically. Apply macOS quarantine and platform protections where applicable; display origin, type, and completion state. | File type and reputation checks can be bypassed; the user remains responsible for opening downloaded content. Test archive/path traversal names and interrupted downloads. |
| Uploads | Show a native open panel; pass only user-selected URLs to the page request. Respect multi-select/directory flags and user cancellation. Avoid persistent bookmarks unless a feature requires them and explains why. | Selected files are intentionally disclosed to the requesting site. Show enough origin context for the user to recognize that action. |
| Site permissions | Default to ask or deny. Key decisions by profile, requesting origin, top-level origin when available, permission kind, and expiry. Show an origin-specific prompt; distinguish one-time from persistent grants; support revocation. Require both engine permission and macOS TCC consent for protected devices. | WebKit and CEF do not expose identical permission sets. Unknown/unmapped requests must fail closed. Keep a matrix per selected engine version. |
| Tamizhi page access | Require an explicit user action for each page-content transfer. Show what source is included (selection, visible page, full page, or user-approved tab set), destination/model, and whether it leaves the device. Minimize data and redact browser chrome, cookies, hidden inputs, password fields, and unrelated tabs. Treat page text as untrusted data, not instructions. | Page text may contain prompt injection or private information. An AI summary can be inaccurate and transmitted content may be retained by downstream systems; disclose the actual retention/processing terms before enabling. |
| Vezham ID and cloud sync | TLS, scoped tokens, server-side authorization, replay protection, rate limits, account/device revocation, and explicit sync controls. Do not sync cookies, passwords, auth sessions, or AI page extracts by default. Encrypt sensitive sync payloads end-to-end if Vezham promises that the service cannot read them; key lifecycle and recovery are prerequisites. | Server compromise, account takeover, recovery flows, and metadata leakage remain. Keep a data inventory and deletion/export process. |
| Engine and helper supply chain | Pin engine version and checksums. Track advisories, bundled third-party licenses, and CVEs. Build from a controlled pipeline; use Developer ID signing and notarization as required by accepted ADR 0002; validate hardened-runtime, sandbox, and updater controls; sign nested helpers/frameworks where applicable. Do not ship a disabled or misconfigured sandbox as a release fallback. | Exact installer/updater and entitlement details remain open. CEF has a separate release cadence that may trail Chromium. Establish an urgent patch and rollback process before release. [CEF security/update notes](https://github.com/chromiumembedded/cef/blob/master/README.md), [Apple notarization](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution) |

## Engine-specific security notes

### WebKit

WebKit’s public API reports web-content process termination and documents a separate process for web content. Vezham should treat WebKit’s process isolation as platform-managed and avoid assuming that the host app’s sandbox entitlements are a configurable per-tab WebKit policy. For App Store distribution, App Sandbox is required; it limits the host app’s access but does not eliminate renderer or bridge risks. [Web-content process termination](https://developer.apple.com/documentation/webkit/wknavigationdelegate/webviewwebcontentprocessdidterminate%28_%3A%29), [App Sandbox](https://developer.apple.com/documentation/security/app-sandbox)

### Chromium through CEF

Chromium’s model separates the browser from renderer processes and uses OS sandboxing; CEF packages helpers but requires Vezham to correctly configure the macOS sandbox, signing identities, and role-specific entitlements. Renderer/GPU processes may need JIT-related hardened-runtime entitlements, which should be granted only to the processes that require them. Do not cargo-cult Chrome signing entitlements: CEF’s own signing guidance says identity-specific Chrome entitlements should not be copied. [Chromium architecture](https://www.chromium.org/developers/design-documents/multi-process-architecture/), [CEF sandbox](https://chromiumembedded.github.io/cef/sandbox_setup), [CEF code signing](https://chromiumembedded.github.io/cef/code_signing.html)

## Phase 2 security gates

Before implementing an engine adapter, approve:

1. Confirmed product baseline: macOS 26 Tahoe+ and internal-only distribution. Follow accepted ADR 0002 for Developer ID signing/notarization; decide installer/updater details and validate hardened runtime, App Sandbox, and entitlements before a distributable build.
2. App Sandbox and hardened-runtime policy, with a written justification for every entitlement/exception.
3. Profile isolation matrix and private-profile data deletion semantics.
4. Permission inventory, default behavior, persistence duration, and OS TCC prompt behavior.
5. A bridge policy forbidding general page-to-native calls and exposing no secrets to page JavaScript.
6. Download/upload UX and filesystem access model.
7. Tamizhi content-access scopes, destination disclosure, retention policy, and data minimization.
8. Vezham ID and sync data inventory, token/key storage, opt-in defaults, revocation, and deletion design.
9. Engine update SLAs and security response owner. If CEF is selected later, include helper signing, sandbox verification, license notices, and urgent Chromium patching.

This threat model is a design baseline, not a security certification. Independent review and adversarial testing are required before public release.
